import React, { useState } from 'react';
import { submitLead, saveLeadLocally } from '../services/mockBackend';
import { ConnectionStatus } from '../types';
import { Button, Input, Icon } from './UI';

interface LeadFormProps {
  networkStatus: ConnectionStatus;
  onClose: () => void;
}

export const LeadForm: React.FC<LeadFormProps> = ({ networkStatus, onClose }) => {
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', message: '' });
  const [status, setStatus] = useState<'IDLE' | 'SUBMITTING' | 'SUCCESS' | 'QUEUED'>('IDLE');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('SUBMITTING');

    try {
      // Try to submit to backend
      await submitLead(formData);
      setStatus('SUCCESS');
    } catch (error) {
      // Fallback strategy: Save to queue
      saveLeadLocally(formData);
      setStatus('QUEUED');
    }
  };

  if (status === 'SUCCESS') {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center h-full">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center text-green-600 mb-4">
          <Icon name="check_circle" className="text-5xl" />
        </div>
        <h3 className="text-2xl font-bold mb-2">Đã gửi yêu cầu!</h3>
        <p className="text-gray-600 mb-6">Chuyên viên tư vấn Sarah sẽ liên hệ với bạn sớm.</p>
        <Button onClick={onClose}>Đóng</Button>
      </div>
    );
  }

  if (status === 'QUEUED') {
    return (
      <div className="p-8 text-center flex flex-col items-center justify-center h-full">
        <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mb-4">
          <Icon name="wifi_off" className="text-5xl" />
        </div>
        <h3 className="text-2xl font-bold mb-2">Đã lưu kết nối</h3>
        <p className="text-gray-600 mb-6 max-w-xs">
          Mạng của bạn có vẻ không ổn định. Chúng tôi đã lưu thông tin an toàn trên thiết bị này và sẽ tự động gửi cho môi giới khi có mạng trở lại.
        </p>
        <Button onClick={onClose} variant="outlined">Đã hiểu</Button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b border-surfaceVariant flex justify-between items-center">
        <h2 className="text-xl font-bold">Liên hệ Môi giới</h2>
        <button onClick={onClose} className="p-2 hover:bg-surfaceVariant rounded-full">
          <Icon name="close" />
        </button>
      </div>
      
      <form onSubmit={handleSubmit} className="p-6 flex-1 overflow-y-auto">
        <p className="text-sm text-gray-500 mb-6">
          Bạn quan tâm đến Resilience Heights? Hãy điền thông tin bên dưới.
          {networkStatus === ConnectionStatus.OFFLINE && 
            <span className="block text-red-500 mt-1 flex items-center gap-1 font-medium">
              <Icon name="offline_bolt" className="text-sm" /> Chế độ Ngoại tuyến - Dữ liệu sẽ được xếp hàng chờ.
            </span>
          }
        </p>

        <Input 
          label="Họ và Tên" 
          required
          value={formData.name}
          onChange={e => setFormData({...formData, name: e.target.value})}
        />
        <Input 
          label="Số điện thoại" 
          type="tel"
          required
          value={formData.phone}
          onChange={e => setFormData({...formData, phone: e.target.value})}
        />
        <Input 
          label="Email" 
          type="email"
          value={formData.email}
          onChange={e => setFormData({...formData, email: e.target.value})}
        />
        <Input 
          label="Lời nhắn" 
          multiline 
          rows={3}
          value={formData.message}
          onChange={e => setFormData({...formData, message: e.target.value})}
        />

        <div className="mt-8">
          <Button 
            type="submit" 
            className="w-full" 
            disabled={status === 'SUBMITTING'}
          >
            {status === 'SUBMITTING' ? 'Đang xử lý...' : 'Gửi yêu cầu'}
          </Button>
        </div>
      </form>
    </div>
  );
};