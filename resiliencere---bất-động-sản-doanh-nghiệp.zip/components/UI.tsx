import React, { useEffect, useState } from 'react';

// --- Button ---
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'filled' | 'outlined' | 'text' | 'fab';
  icon?: React.ReactNode;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'filled', 
  className = '', 
  icon,
  ...props 
}) => {
  const baseStyle = "inline-flex items-center justify-center gap-2 font-medium transition-all duration-200 ripple rounded-full";
  
  const variants = {
    filled: "bg-primary text-onPrimary hover:bg-opacity-90 shadow-sm px-6 py-2.5",
    outlined: "border border-outline text-primary hover:bg-surfaceVariant px-6 py-2.5",
    text: "text-primary hover:bg-surfaceVariant px-4 py-2",
    fab: "fixed bottom-6 right-6 w-14 h-14 rounded-2xl bg-primaryContainer text-onPrimaryContainer shadow-lg hover:shadow-xl z-50",
  };

  return (
    <button 
      className={`${baseStyle} ${variants[variant]} ${props.disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}
      {...props}
    >
      {icon}
      {children}
    </button>
  );
};

// --- Input ---
interface InputProps extends React.InputHTMLAttributes<HTMLInputElement | HTMLTextAreaElement> {
  label: string;
  error?: string;
  multiline?: boolean;
  rows?: number;
}

export const Input: React.FC<InputProps> = ({ label, error, multiline, className = '', ...props }) => {
  const Component = multiline ? 'textarea' : 'input';
  
  return (
    <div className={`relative mb-4 ${className}`}>
      <Component
        className={`
          peer block w-full rounded-t-lg border-b-2 border-outline bg-surfaceVariant px-4 pb-2.5 pt-6 text-onSurface focus:border-primary focus:outline-none placeholder-transparent
          ${error ? 'border-error' : ''}
        `}
        placeholder=" "
        {...props as any}
      />
      <label
        className={`
          pointer-events-none absolute left-4 top-4 origin-[0] -translate-y-3 scale-75 transform text-sm text-gray-500 duration-200 peer-placeholder-shown:translate-y-0 peer-placeholder-shown:scale-100 peer-focus:-translate-y-3 peer-focus:scale-75 peer-focus:text-primary
          ${error ? 'text-error peer-focus:text-error' : ''}
        `}
      >
        {label}
      </label>
      {error && <span className="text-xs text-error mt-1 ml-4">{error}</span>}
    </div>
  );
};

// --- Card ---
export const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-surface rounded-3xl p-6 shadow-sm border border-surfaceVariant ${className}`}>
    {children}
  </div>
);

// --- Badge ---
export const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  let label = status;
  let colorClass = "bg-gray-100 text-gray-800";
  
  if (status === 'ONLINE') {
      colorClass = "bg-green-100 text-green-800";
      label = "TRỰC TUYẾN";
  }
  if (status === 'DEGRADED') {
      colorClass = "bg-yellow-100 text-yellow-800";
      label = "CHẬP CHỜN";
  }
  if (status === 'OFFLINE') {
      colorClass = "bg-red-100 text-red-800";
      label = "MẤT KẾT NỐI";
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colorClass}`}>
      {label}
    </span>
  );
};

// --- Icon Helper ---
export const Icon: React.FC<{ name: string; className?: string }> = ({ name, className = '' }) => (
  <span className={`material-symbols-rounded ${className}`}>{name}</span>
);

// --- Toast Notification ---
interface ToastProps {
  message: string;
  type?: 'info' | 'success' | 'warning' | 'error';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type = 'info', onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 4000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const bgColors = {
    info: 'bg-surfaceVariant text-onSurface',
    success: 'bg-green-100 text-green-900',
    warning: 'bg-yellow-100 text-yellow-900',
    error: 'bg-red-100 text-red-900'
  };

  return (
    <div className={`fixed top-20 left-1/2 transform -translate-x-1/2 z-50 px-4 py-3 rounded-xl shadow-lg flex items-center gap-3 animate-fade-in ${bgColors[type]}`}>
      <Icon name={type === 'error' ? 'error' : type === 'warning' ? 'warning' : 'info'} />
      <span className="text-sm font-medium">{message}</span>
    </div>
  );
};