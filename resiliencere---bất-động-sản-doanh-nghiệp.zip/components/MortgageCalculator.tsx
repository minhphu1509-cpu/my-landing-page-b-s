import React, { useState, useEffect } from 'react';
import { Card, Input, Button, Icon } from './UI';

interface MortgageCalculatorProps {
  propertyPrice: number;
}

export const MortgageCalculator: React.FC<MortgageCalculatorProps> = ({ propertyPrice }) => {
  const [downPayment, setDownPayment] = useState(propertyPrice * 0.3);
  const [interestRate, setInterestRate] = useState(8.5); // Adjusted for Vietnam market typically higher
  const [loanTerm, setLoanTerm] = useState(20);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  const calculate = () => {
    const principal = propertyPrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm * 12;

    if (monthlyRate === 0) {
      setMonthlyPayment(principal / numberOfPayments);
    } else {
      const payment =
        (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) /
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
      setMonthlyPayment(payment);
    }
  };

  useEffect(() => {
    calculate();
  }, [downPayment, interestRate, loanTerm, propertyPrice]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND', maximumFractionDigits: 0 }).format(val);
  }

  return (
    <div className="space-y-4">
      <Card className="bg-primaryContainer text-onPrimaryContainer">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white/20 rounded-full">
            <Icon name="payments" className="text-3xl" />
          </div>
          <div>
            <p className="text-sm opacity-80">Thanh toán hàng tháng (Ước tính)</p>
            <p className="text-2xl font-bold">{formatCurrency(monthlyPayment)}</p>
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-surfaceVariant">
          <label className="text-xs text-gray-500 font-bold uppercase mb-2 block">Trả trước (VND)</label>
          <input 
            type="range" 
            min={0} 
            max={propertyPrice} 
            step={10000000}
            value={downPayment} 
            onChange={(e) => setDownPayment(Number(e.target.value))}
            className="w-full accent-primary h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mb-2"
          />
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium truncate mr-2">{formatCurrency(downPayment)}</span>
            <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600 whitespace-nowrap">
              {((downPayment / propertyPrice) * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-surfaceVariant">
          <label className="text-xs text-gray-500 font-bold uppercase mb-2 block">Kỳ hạn vay (Năm)</label>
          <div className="flex gap-2">
            {[10, 15, 20, 25].map(yr => (
              <button
                key={yr}
                onClick={() => setLoanTerm(yr)}
                className={`flex-1 py-2 text-sm rounded-lg border ${loanTerm === yr ? 'bg-primary text-white border-primary' : 'bg-transparent border-outline text-gray-600'}`}
              >
                {yr}
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="bg-surfaceVariant/50 p-4 rounded-xl text-xs text-gray-500 flex gap-2">
         <Icon name="info" className="text-sm" />
         <p>Công cụ này hoạt động hoàn toàn ngoại tuyến. Lãi suất chỉ mang tính chất tham khảo và chưa bao gồm thuế hay bảo hiểm.</p>
      </div>
    </div>
  );
};