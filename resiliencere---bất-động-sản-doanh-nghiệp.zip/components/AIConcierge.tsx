import React, { useState, useRef, useEffect } from 'react';
import { generatePropertyResponse } from '../services/geminiService';
import { Property, ConnectionStatus } from '../types';
import { Button, Icon } from './UI';

interface AIConciergeProps {
  property: Property | null;
  networkStatus: ConnectionStatus;
}

interface Message {
  role: 'user' | 'ai';
  text: string;
}

export const AIConcierge: React.FC<AIConciergeProps> = ({ property, networkStatus }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'ai', text: 'Xin chào! Tôi là Trợ lý AI của Resilience Heights. Tôi có thể giúp gì cho bạn hôm nay?' }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages, isOpen]);

  // Text-to-Speech Helper (Vietnamese)
  const speak = (text: string) => {
    if (!voiceEnabled || !window.speechSynthesis) return;
    window.speechSynthesis.cancel(); // Stop previous
    const utterance = new SpeechSynthesisUtterance(text);
    // Try to find a Vietnamese voice
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.lang.includes('vi')) || voices[0];
    if (preferredVoice) utterance.voice = preferredVoice;
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async () => {
    if (!inputText.trim()) return;

    const userMsg = inputText;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInputText('');
    setIsTyping(true);

    // Build context from property data
    const context = property ? `
      Tên dự án: ${property.title}
      Giá: ${property.price}
      Vị trí: ${property.location}
      Mô tả: ${property.description}
      Tiện ích: ${property.features.join(', ')}
      Môi giới: ${property.agentName}
    ` : "Thông tin chi tiết hiện không khả dụng.";

    const aiResponse = await generatePropertyResponse(userMsg, context);

    setMessages(prev => [...prev, { role: 'ai', text: aiResponse }]);
    setIsTyping(false);
    speak(aiResponse);
  };

  return (
    <>
      {/* Floating Action Button */}
      {!isOpen && (
        <Button 
          variant="fab" 
          onClick={() => setIsOpen(true)} 
          className="animate-bounce-in flex flex-col items-center justify-center gap-0"
          aria-label="Open AI Concierge"
        >
          <Icon name="smart_toy" className="text-2xl" />
        </Button>
      )}

      {/* Chat Interface */}
      {isOpen && (
        <div className="fixed bottom-0 right-0 w-full md:w-96 md:bottom-6 md:right-6 md:rounded-3xl bg-surface shadow-2xl z-50 flex flex-col h-[550px] border border-surfaceVariant animate-slide-up">
          
          {/* Header */}
          <div className="p-4 bg-primaryContainer text-onPrimaryContainer rounded-t-3xl flex justify-between items-center shadow-sm z-10">
             <div className="flex items-center gap-3">
               <div className="bg-white/20 p-2 rounded-full">
                  <Icon name="smart_toy" />
               </div>
               <div>
                 <span className="font-bold block text-sm">Trợ lý Resilience</span>
                 <span className="text-xs opacity-80 flex items-center gap-1">
                   <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                   Trực tuyến
                 </span>
               </div>
             </div>
             <div className="flex gap-1">
               <button 
                  onClick={() => {
                    setVoiceEnabled(!voiceEnabled);
                    if(voiceEnabled) window.speechSynthesis.cancel();
                  }} 
                  className={`p-2 rounded-full transition-colors ${voiceEnabled ? 'bg-primary text-white' : 'hover:bg-black/5'}`}
                  title="Bật/Tắt giọng nói"
               >
                 <Icon name={voiceEnabled ? "volume_up" : "volume_off"} />
               </button>
               <button onClick={() => setIsOpen(false)} className="hover:bg-black/10 rounded-full p-2">
                 <Icon name="expand_more" />
               </button>
             </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50/50">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`
                  max-w-[85%] rounded-2xl p-3 text-sm shadow-sm
                  ${msg.role === 'user' 
                    ? 'bg-primary text-onPrimary rounded-tr-sm' 
                    : 'bg-white text-gray-800 border border-gray-100 rounded-tl-sm'}
                `}>
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white text-gray-500 border border-gray-100 rounded-2xl rounded-tl-sm p-3 text-xs flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-75"></div>
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-4 border-t border-surfaceVariant bg-white rounded-b-3xl">
            {networkStatus === ConnectionStatus.OFFLINE ? (
               <div className="text-center text-sm text-gray-500 flex flex-col items-center gap-2 py-2">
                 <Icon name="wifi_off" className="text-2xl opacity-50"/>
                 <span>Trợ lý AI không khả dụng khi mất mạng.</span>
               </div>
            ) : (
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Hỏi về giá, chỗ đậu xe..."
                  className="flex-1 bg-gray-100 rounded-full px-4 py-3 text-sm focus:outline-none focus:ring-2 ring-primary transition-all"
                />
                <button 
                  onClick={handleSend}
                  disabled={isTyping}
                  className="bg-primary text-onPrimary rounded-full w-12 h-12 flex items-center justify-center hover:shadow-lg transition-all active:scale-95 disabled:opacity-50 disabled:shadow-none"
                >
                  <Icon name="send" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
};