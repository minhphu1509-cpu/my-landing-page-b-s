import React, { useState } from 'react';
import { Property, TabView, ConnectionStatus } from '../types';
import { Button, Card, Icon } from './UI';
import { MortgageCalculator } from './MortgageCalculator';

interface PropertyViewProps {
  property: Property;
  loading: boolean;
  networkStatus: ConnectionStatus;
  onRefresh: () => void;
}

export const PropertyView: React.FC<PropertyViewProps> = ({ property, loading, networkStatus, onRefresh }) => {
  const [activeTab, setActiveTab] = useState<TabView>(TabView.OVERVIEW);

  if (loading) {
    return (
      <div className="animate-pulse space-y-4 p-4 max-w-4xl mx-auto">
        <div className="h-64 bg-gray-300 rounded-3xl w-full"></div>
        <div className="h-8 bg-gray-300 rounded w-3/4"></div>
        <div className="h-4 bg-gray-300 rounded w-1/2"></div>
        <div className="h-32 bg-gray-300 rounded w-full"></div>
      </div>
    );
  }

  // Graceful degradation: Fallback content
  const displayProperty = property || {
    title: "Resilience Heights (Bản lưu)",
    price: "Liên hệ báo giá",
    priceRaw: 0,
    location: "Quận 1, TP. HCM",
    description: "Bạn đang xem phiên bản lưu trữ của tin đăng này do sự cố mạng. Các thông tin cốt lõi vẫn được bảo lưu.",
    features: ["Tính năng tiêu chuẩn"],
    imageUrl: "https://picsum.photos/1200/800?grayscale",
    videoUrl: "",
    agentName: "Đội ngũ Hỗ trợ",
    agentPhone: ""
  };

  // Smart Media Strategy: Only play video if ONLINE. Else show image.
  const canPlayVideo = networkStatus === ConnectionStatus.ONLINE && displayProperty.videoUrl;

  return (
    <div className="pb-24">
      {/* Hero Media Section */}
      <div className="relative w-full h-80 md:h-[450px] overflow-hidden rounded-b-3xl shadow-lg group">
        {canPlayVideo ? (
          <video 
            autoPlay 
            muted 
            loop 
            playsInline
            className="w-full h-full object-cover animate-fade-in"
            poster={displayProperty.imageUrl}
          >
            <source src={displayProperty.videoUrl} type="video/mp4" />
          </video>
        ) : (
          <img 
            src={displayProperty.imageUrl} 
            alt={displayProperty.title} 
            className={`w-full h-full object-cover transition-all duration-700 ${networkStatus !== ConnectionStatus.ONLINE ? 'grayscale-[0.3]' : ''}`}
          />
        )}
        
        {/* Connection Status Overlay for Media */}
        <div className="absolute top-4 right-4 bg-black/40 backdrop-blur-md text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 border border-white/20">
          <Icon name={canPlayVideo ? "play_circle" : "image"} className="text-sm" />
          <span>{canPlayVideo ? "Video 4K" : "Ảnh tĩnh (Tiết kiệm)"}</span>
        </div>

        <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 pt-24">
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-2 tracking-tight">{displayProperty.title}</h1>
            <div className="flex items-center text-white/90 gap-2">
              <Icon name="location_on" className="text-sm" />
              <span className="text-sm md:text-lg font-light">{displayProperty.location}</span>
            </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 md:p-6 -mt-8 relative z-10">
        
        {/* Price Card */}
        <Card className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 shadow-xl border-none bg-white gap-4">
          <div>
            <p className="text-sm text-gray-500 font-medium uppercase tracking-wider">Giá niêm yết</p>
            <p className="text-3xl font-bold text-primary">{displayProperty.price}</p>
          </div>
          <div className="flex gap-2 w-full md:w-auto">
             <Button variant="outlined" className="flex-1 md:flex-none" onClick={onRefresh} icon={<Icon name="refresh" />}>
                Tải lại
             </Button>
             <Button variant="filled" className="flex-1 md:flex-none" icon={<Icon name="calendar_month" />}>
                Đặt lịch xem
             </Button>
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
          {Object.values(TabView).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`
                px-6 py-2.5 rounded-full text-sm font-bold whitespace-nowrap transition-all
                ${activeTab === tab 
                  ? 'bg-primary text-white shadow-md' 
                  : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}
              `}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="min-h-[300px] animate-fade-in">
          {activeTab === TabView.OVERVIEW && (
            <div className="space-y-6">
              <section>
                <h2 className="text-xl font-bold mb-3 text-onSurface flex items-center gap-2">
                   <Icon name="description" className="text-primary" /> Giới thiệu
                </h2>
                <p className="text-gray-600 leading-relaxed text-lg">{displayProperty.description}</p>
              </section>
              
              <section>
                 <h2 className="text-xl font-bold mb-3 text-onSurface flex items-center gap-2">
                   <Icon name="shield" className="text-primary" /> Tính năng bền vững
                 </h2>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                   {displayProperty.features.map((feature, idx) => (
                     <div key={idx} className="flex items-center gap-3 p-4 bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                       <div className="w-10 h-10 rounded-full bg-primaryContainer flex items-center justify-center text-onPrimaryContainer">
                         <Icon name="check" />
                       </div>
                       <span className="text-gray-700 font-medium">{feature}</span>
                     </div>
                   ))}
                 </div>
              </section>
            </div>
          )}

          {activeTab === TabView.AMENITIES && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {[1,2,3,4].map(i => (
                 <div key={i} className="group relative overflow-hidden rounded-2xl shadow-sm aspect-video cursor-pointer">
                    <img 
                      src={`https://picsum.photos/400/300?random=${i + 10}`} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      alt="Tiện ích" 
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-80" />
                    <div className="absolute bottom-4 left-4 text-white">
                       <h3 className="font-bold text-lg">Tiện ích cao cấp {i}</h3>
                       <p className="text-xs text-gray-300">Bao gồm trang thiết bị quốc tế</p>
                    </div>
                 </div>
               ))}
            </div>
          )}
          
          {activeTab === TabView.CALCULATOR && (
             <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold mb-4 text-onSurface flex items-center gap-2">
                   <Icon name="calculate" className="text-primary" /> Ước tính khoản vay
                </h2>
                <MortgageCalculator propertyPrice={displayProperty.priceRaw} />
             </div>
          )}

          {activeTab === TabView.LOCATION && (
            <div className="h-80 bg-gray-200 rounded-3xl flex items-center justify-center relative overflow-hidden border border-gray-300">
               {networkStatus === ConnectionStatus.ONLINE ? (
                  <div className="w-full h-full relative">
                    <img src="https://picsum.photos/800/400?blur=2" className="w-full h-full object-cover opacity-50" />
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl animate-bounce">
                         <Icon name="location_on" className="text-3xl text-red-500" />
                      </div>
                      <p className="mt-4 font-bold text-gray-700 bg-white/80 px-4 py-2 rounded-full backdrop-blur">
                        Bản đồ tương tác (Mô phỏng)
                      </p>
                    </div>
                  </div>
               ) : (
                  // Fallback for maps
                  <div className="w-full h-full bg-orange-50 flex flex-col items-center justify-center text-orange-800 p-8 text-center">
                    <Icon name="map_off" className="text-5xl mb-4 opacity-50" />
                    <p className="font-bold text-lg">Dữ liệu bản đồ ngoại tuyến</p>
                    <p className="text-sm opacity-80 mb-4">Điều hướng chi tiết hiện không khả dụng. Vui lòng sử dụng tọa độ bên dưới.</p>
                    <div className="bg-white/50 px-4 py-2 rounded-lg font-mono text-sm border border-orange-200">
                      10.7769° N, 106.7009° E
                    </div>
                  </div>
               )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};