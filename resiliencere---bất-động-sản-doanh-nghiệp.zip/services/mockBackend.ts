import { Property, Lead, ConnectionStatus, ServerRegion } from '../types';

// Mock Data
const MOCK_PROPERTY: Property = {
  id: 'prop-001',
  title: 'Resilience Heights - Biệt thự trên không',
  price: '29,5 Tỷ VND',
  priceRaw: 29500000000,
  location: 'Quận 1, TP. Hồ Chí Minh',
  description: 'Trải nghiệm đỉnh cao của sự sang trọng tại kiệt tác kiến trúc "không bao giờ ngủ" này. Được thiết kế cho giới thượng lưu, Resilience Heights mang đến tầm nhìn toàn cảnh không giới hạn, tích hợp nhà thông minh và hệ thống điện dự phòng riêng biệt. Căn hộ này sở hữu 3 phòng ngủ, hồ bơi vô cực riêng và thang máy dẫn thẳng vào nhà.',
  features: [
    'Hồ bơi vô cực riêng',
    'Nhà thông minh (Điện dự phòng)',
    'Lễ tân Concierge 24/7',
    'Thang máy riêng',
    'Vườn treo Sky Garden',
    'Internet đa vùng (Multi-Region)'
  ],
  imageUrl: 'https://images.unsplash.com/photo-1600596542815-e32c8ec22dc2?q=80&w=2070&auto=format&fit=crop',
  videoUrl: 'https://videos.pexels.com/video-files/3752603/3752603-uhd_2560_1440_24fps.mp4',
  agentName: 'Sarah Jenkins',
  agentPhone: '090 123 4567'
};

// Simulation State
let networkCondition = ConnectionStatus.ONLINE;
let currentRegion = ServerRegion.PRIMARY;

export const setNetworkCondition = (status: ConnectionStatus) => {
  networkCondition = status;
  // Automatic Failover Logic Simulation
  if (status === ConnectionStatus.ONLINE) {
    currentRegion = ServerRegion.PRIMARY;
  } else if (status === ConnectionStatus.DEGRADED) {
    currentRegion = ServerRegion.BACKUP;
  } else {
    currentRegion = ServerRegion.EDGE;
  }
};

export const getNetworkCondition = () => networkCondition;
export const getServerRegion = () => currentRegion;

// Mock Content Service
export const fetchPropertyDetails = async (): Promise<Property> => {
  // Simulate network delay based on region
  const delay = networkCondition === ConnectionStatus.DEGRADED ? 1500 : 600;
  await new Promise(resolve => setTimeout(resolve, delay));

  if (networkCondition === ConnectionStatus.OFFLINE) {
    throw new Error("Lỗi mạng: 503 Dịch vụ không khả dụng");
  }

  return MOCK_PROPERTY;
};

// Mock Lead Service (Queue System)
export const submitLead = async (lead: Omit<Lead, 'id' | 'submittedAt' | 'synced'>): Promise<void> => {
  await new Promise(resolve => setTimeout(resolve, 1000));

  if (networkCondition === ConnectionStatus.OFFLINE) {
    throw new Error("Mạng không khả dụng");
  }
  
  // Success
  return;
};

// Local Storage Manager (The Fallback)
const LEAD_STORAGE_KEY = 'offline_leads_queue';

export const saveLeadLocally = (lead: Omit<Lead, 'id' | 'submittedAt' | 'synced'>) => {
  const currentQueue: Lead[] = JSON.parse(localStorage.getItem(LEAD_STORAGE_KEY) || '[]');
  const newLead: Lead = {
    ...lead,
    id: `local-${Date.now()}`,
    submittedAt: Date.now(),
    synced: false
  };
  currentQueue.push(newLead);
  localStorage.setItem(LEAD_STORAGE_KEY, JSON.stringify(currentQueue));
};

export const getLocalLeads = (): Lead[] => {
  return JSON.parse(localStorage.getItem(LEAD_STORAGE_KEY) || '[]');
};

export const clearLocalLeads = () => {
  localStorage.removeItem(LEAD_STORAGE_KEY);
};