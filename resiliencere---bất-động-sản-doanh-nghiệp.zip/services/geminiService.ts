import { GoogleGenAI } from "@google/genai";

// Initialize Gemini Client
// In a real app, API_KEY comes from process.env.API_KEY.
// For this environment, we assume it's injected.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generatePropertyResponse = async (
  userQuery: string,
  propertyContext: string
): Promise<string> => {
  if (!process.env.API_KEY) {
    return "Tôi hiện đang ở chế độ ngoại tuyến. Vui lòng liên hệ trực tiếp với nhân viên tư vấn qua điện thoại.";
  }

  try {
    const model = 'gemini-3-flash-preview';
    const systemInstruction = `
      Bạn là Trợ lý AI Bất động sản chuyên nghiệp cho dự án hạng sang "Resilience Heights".
      Phong cách của bạn: Chuyên nghiệp, ấm áp và hữu ích. Hãy trả lời hoàn toàn bằng Tiếng Việt.
      Sử dụng thông tin bất động sản được cung cấp để trả lời câu hỏi.
      Nếu câu trả lời không có trong thông tin, hãy lịch sự đề nghị khách hàng liên hệ với chuyên viên tư vấn Sarah Jenkins.
      Giữ câu trả lời ngắn gọn (dưới 50 từ trừ khi được yêu cầu chi tiết).
      
      Thông tin bất động sản:
      ${propertyContext}
    `;

    const response = await ai.models.generateContent({
      model: model,
      contents: userQuery,
      config: {
        systemInstruction: systemInstruction,
      },
    });

    return response.text || "Xin lỗi, tôi không thể xử lý yêu cầu lúc này.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Tôi đang gặp sự cố kết nối với cơ sở dữ liệu. Vui lòng thử lại hoặc gọi trực tiếp cho nhân viên tư vấn.";
  }
};